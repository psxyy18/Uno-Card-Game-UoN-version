UNO Card Game (Group Project from Group 5)


ABOUT RULES:

DO NOT CLICK THE MOUSE ARBITRARILY, OR THERE WILL BE SOME MISTAKES. JUST FOLLOW THE RULES EXACTLY

1. When it is your turn, you should choose a card to discard and a card will join in your hand automatically

2. after 1., if there is a card that can be played, you must play it. If there is not, click your card area, and there will be a card joining your hand card and if it can be played, it played automatically as well.

3. after doing 1. & 2., when there are 2 cards left in your hand, and one of them can be played, you should click it to play and click UNO button before clicking �� button (which means to end turn). If not, you will get a panelty card

4. There is also a emoji button beside, but do not send emoji between 1. & 2. , you can click it before 1. or after 2.


