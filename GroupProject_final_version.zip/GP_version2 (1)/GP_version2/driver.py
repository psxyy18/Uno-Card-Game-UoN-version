#reference <https://www.youtube.com/watch?v=cVX7hR3bX7A>
from AI_action import *
from classes import *
from deck import *
from player_action import *
import time
from leaderboard import *


pygame.init()

img = Image()
pm = Mode()
sound = Sound()
fnt = TextFont()


root = pygame.display.set_mode((1000, 600))
pygame.display.set_caption('UNO')
pygame.display.set_icon(img.icon)


pygame.mixer.music.load(sound.back_g)
pygame.mixer.music.play(-1) 
pygame.mixer.music.set_volume(0.3) 
music_on = True  


active = True 
a.play_mode = pm.load  

disp = False
win_dec = False  
pen_check = False 
emo_chosen = -1
discard_flag = False



while active:
    
    for inp in pygame.event.get():

     
        if inp.type == pygame.QUIT:
            active = False

    
        if inp.type == pygame.MOUSEBUTTONDOWN:
            m = pygame.mouse.get_pos()  

            if (750 < m[0] < 785 or 940 < m[0] < 975) and (120< m[1] < 150) and a.play_mode == pm.load:  
                if music_on:
                    sound.click.play()
                if a.level1ai:
                    a.level1ai = False
                else:
                    a.level1ai = True

            if 925 < m[0] < 990 and 500 < m[1] < 565 and emo_chosen == -1:  
                a.choose_emoji = True
                if music_on:
                    sound.click.play()

            if 10 < m[0] < 160 and 25 < m[1] < 170 and a.play_mode == pm.load:  
                if music_on:
                    sound.click.play()
                a.play_mode = pm.turn


            if 10 < m[0] < 42 and 10 < m[1] < 42 and (
                    a.play_mode == pm.in_game): 
                if music_on:
                    sound.click.play()
                a.re_set()
                a.play_mode = pm.load

            if 420 < m[0] < 555 and 425 < m[1] < 543 and a.play_mode == pm.win:  
                if music_on:
                    sound.click.play()
                a.re_set()
                win_dec = False
                a.play_mode = pm.load

            if 960 < m[0] < 1000 and 0 < m[1] < 40:  
                if music_on:
                    sound.click.play()
                if music_on:
                    pygame.mixer.music.pause()
                    music_on = False
                else:
                    pygame.mixer.music.unpause()
                    music_on = True

            if a.playing_check:  
                if 850 < m[0] < 916 and 500 < m[1] < 565:  # UNO button
                    if music_on:
                        sound.win_check.play()

                    a.win_check[0] = True

                if 775 < m[0] < 840 and 505 < m[1] < 570: 
                    emo_chosen = -1
                    if music_on:
                        sound.click.play()
                    a.playing_check = False


                if a.discard is True:
                    if a.drawn is False:
                        a.draw_from_stack( a.players_cards_list[0])
                        if a.drawn and ((a.players_cards_list[0][-1][0] == a.current_card[0] or a.players_cards_list[0][-1][1] == a.current_card[1]) or
                                a.players_cards_list[0][-1][0] in ('+4', 'Wild')):
                            if a.players_cards_list[0][-1][1] != 'Black':
                                a.playing_check = False
                            a.play_card( a.players_cards_list[0][-1])
                            a.discard = False

                    for i in range(625, 625 - 50 * len(a.players_cards_list[0]),
                                   -50): 
                        if i < m[0] < i + 50 and 470 < m[1] < 585:

                            a.play_card(a.players_cards_list[0][int((625 - i) / 50)])

                    a.discard = False
                    continue

                if a.discard is False:
                    for i in range(625, 625 - 50 * len(a.players_cards_list[0]), -50): 
                        if i < m[0] < i + 50 and 470 < m[1] < 585:
                            a.discard_deck.reverse()
                            a.discard_deck.append(a.players_cards_list[0][int((625 - i) / 50)])
                            a.discard_deck.reverse()
                            a.players_cards_list[0].remove(a.players_cards_list[0][int((625 - i) / 50)])
                            try:
                                a.players_cards_list[0].append(a.draw_deck.pop())
                            except:
                                a.draw_deck, a.discard_deck = a.discard_deck, a.draw_deck
                                random.shuffle(a.draw_deck)
                                a.players_cards_list[0].append(a.draw_deck.pop())

                            a.discard = True
                   
            if a.play_mode == pm.win:


                if (580 <= m[0] <= 580 + 200 and 
                    450 <= m[1] <= 450 + 100):
                    running = False

                if (20 <= m[0] <= 20 + 200 and
                    450 <= m[1] <= 450 + 100):     
                    a.play_mode = pm.load


         
            if a.choose_emoji:
                if 395 < m[0] < 440 and 390 < m[1] < 450:  
                    emo_chosen = 0
                    if music_on:
                        sound.click.play()
                if 450 < m[0] < 495 and 390 < m[1] < 450: 
                    emo_chosen = 1
                    if music_on:
                        sound.click.play()
                if 505 < m[0] < 550 and 390 < m[1] < 450:  
                    emo_chosen = 2
                    if music_on:
                        sound.click.play()
                if 560 < m[0] < 605 and 390 < m[1] < 450: 
                    emo_chosen = 3
                    if music_on:
                        sound.click.play()

            if a.color_chosen:
                choose_a_color(m, a, music_on, sound)


    if a.play_mode == pm.load:
       
        root.blit(img.load, (0, 0))
        text = pygame.font.Font(fnt.silom, 50).render("<", True, (0 , 0 , 128))
        root.blit(text, [750, 120])
        text = pygame.font.Font(fnt.silom, 50).render(">", True, (0 , 0 , 128))
        root.blit(text, [950, 120])
        if a.level1ai:
            text = pygame.font.Font(fnt.silom, 30).render("LEVEL 1", True, (0 , 0 , 128))
            root.blit(text, [818, 127])
        else:
            text = pygame.font.Font(fnt.silom, 30).render("LEVEL 2", True, (0 , 0 , 128))
            root.blit(text, [818, 127])

    elif a.play_mode == pm.turn:
        root.blit(img.bg, (0, 0))
        root.blit(img.back, (10, 10))
        root.blit(img.p1, (290, 30))
        root.blit(img.p2, (865, 90))
        root.blit(img.p3, (55, 440))
        root.blit(img.p4, (675, 490))
        text = pygame.font.Font(fnt.silom, 25).render("YOU", True, (255, 238, 46))
        root.blit(text, [690, 460])
        text = pygame.font.Font(fnt.silom, 25).render("PRINCE JOHN", True, (255, 238, 46))
        root.blit(text, [270, 4])
        text = pygame.font.Font(fnt.silom, 25).render("MAID MARIAN", True, (255, 238, 46))
        root.blit(text, [830, 60])
        text = pygame.font.Font(fnt.silom, 25).render("ROBINHOOD", True, (255, 238, 46))
        root.blit(text, [30, 410])
        text = pygame.font.Font(fnt.silom, 25).render(a.background_voice, True, (255, 238, 46))
        root.blit(text, [340, 210])
        lista = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        random.shuffle(lista)
        result = lista[0:4]
        print(result)

        root.blit(pygame.image.load("./images/Blue" + str(result[0]) + ".png"), (590 - 50 * 3, 470))
        root.blit(pygame.image.load("./images/Blue" + str(result[1]) + ".png"), (40, 315 - 30 * 3))
        root.blit(pygame.image.load("./images/Blue" + str(result[2]) + ".png"), (380 + 30 * 3, 20))
        root.blit(pygame.image.load("./images/Blue" + str(result[3]) + ".png"), (845, 190 + 30 * 3))

        a.position = result.index(max(result)) - 1
        a.play_mode = pm.in_game
        pen_check = True
        pygame.display.update()
        time.sleep(2)

    elif a.play_mode == pm.in_game:


        for i in a.players_cards_list:
            if len(i) == 0:
                win_dec = True
                print(f"playerlist = {a.players_cards_list.index(i)}")
                a.winner = a.players_cards_list.index(i)
                break

   
        if a.extend_time == -1 and music_on:
            pass


        root.blit(img.bg, (0, 0))
        root.blit(img.back, (10, 10))
        root.blit(img.card_back, (340, 240))
        try:
            root.blit(pygame.image.load("images/" + a.current_card[1] + str(a.current_card[0]) + ".png"), (580, 240))
        except:
            root.blit(pygame.image.load("images/" + a.current_card[1] + ".png"), (580, 240))
        root.blit(img.p1, (290, 30))
        root.blit(img.p2, (865, 90))
        root.blit(img.p3, (55, 440))
        root.blit(img.p4, (675, 490))

        text = pygame.font.Font(fnt.silom, 20).render("YOU", True, (255, 238, 46))
        root.blit(text, [690, 460])
        text = pygame.font.Font(fnt.silom, 20).render("PRINCE JOHN", True, (255, 238, 46))
        root.blit(text, [270, 4])
        text = pygame.font.Font(fnt.silom, 20).render("MAID MARIAN", True, (255, 238, 46))
        root.blit(text, [830, 60])
        text = pygame.font.Font(fnt.silom, 20).render("ROBINHOOD", True, (255, 238, 46))
        root.blit(text, [30, 410])

        text = pygame.font.Font(fnt.silom, 20).render(a.background_voice, True, (255, 238, 46))
        root.blit(text, [340, 210])

 
        for i in range(len(a.players_cards_list[1])):
            root.blit(img.card_back_l, (40, 315 - 30 * i))
        for i in range(len(a.players_cards_list[2])):
            root.blit(img.card_back_i, (380 + 30 * i, 20))
        for i in range(len(a.players_cards_list[3])):
            root.blit(img.card_back_r, (845, 190 + 30 * i))
        for i in range(len(a.players_cards_list[0])):
            root.blit(
                pygame.image.load("images/" + a.players_cards_list[0][i][1] + str(a.players_cards_list[0][i][0]) + ".png"),
                (590 - 50 * i, 470))

        if a.color_chosen:
            root.blit(img.red, (395, 390))
            root.blit(img.green, (450, 390))
            root.blit(img.blue, (505, 390))
            root.blit(img.yellow, (560, 390))

        # send emoji
        if a.choose_emoji:
            root.blit(img.emoji_list[0], (395, 390))
            root.blit(img.emoji_list[1], (450, 390))
            root.blit(img.emoji_list[2], (505, 390))
            root.blit(img.emoji_list[3], (560, 390))
        if emo_chosen > -1 and a.playing_check:
            root.blit(img.dialogue, (750, 450))
            root.blit(img.emoji_list[emo_chosen], (767, 455))
            a.choose_emoji = False


        if a.playing_check: 
            a.background_voice = ""

            if not a.drawn and not a.played: 
                if a.current_card[0] == '+2' and a.check_special == 0:  # Draw 2
                    for _ in range(2):
                        try:
                            a.players_cards_list[0].append(a.draw_deck.pop())
                        except:
                            a.draw_deck, a.discard_deck = a.discard_deck, a.draw_deck
                            random.shuffle(a.draw_deck)
                            a.players_cards_list[0].append(a.draw_deck.pop())
                    a.check_special = 1
                    a.playing_check = False

                elif a.current_card[0] == '+4' and a.check_special == 0:  # Draw 4
                    for _ in range(4):
                        try:
                            a.players_cards_list[0].append(a.draw_deck.pop())
                        except:
                            a.draw_deck, a.discard_deck = a.discard_deck, a.draw_deck
                            random.shuffle(a.draw_deck)
                            a.players_cards_list[0].append(a.draw_deck.pop())
                    a.check_special = 1
                    a.playing_check = False
             

      
            root.blit(img.line, (682, 550))
            root.blit(img.done, (775, 505))
            root.blit(img.emoji, (925, 500))
            root.blit(img.win_check_button, (850, 500))

        else:
            if a.extend_time == 140:  
                disp = False
                pen_check = False

         
                a.next_position(True)

          
                if a.position == 0:
                    a.win_check[0] = False
                    a.playing_check = True

                else:
            
                    a.played = False 
                    a.drawn = False

                    ai_action(a, sound)

                a.extend_time = 0 

            else:
                if win_dec and a.extend_time == 70: 
                    a.play_mode = pm.win

                if not pen_check:  
                    if a.position != -1 and len(a.players_cards_list[a.position]) == 1 and not a.win_check[a.position]:  # Penalty
                  
                        for j in range(2):
                            if a.position != j:
                              
                                a.players_cards_list[a.position].append(a.players_cards_list[j].pop())

                        a.background_voice = "Penalty!"
                        a.win_check[a.position] = True
                    pen_check = True

                a.extend_time += 1

                if not disp:
                    disp = True

                if (a.position + a.direction) % 4 == 1:
                    root.blit(img.line, (67, 512))
                elif (a.position + a.direction) % 4 == 2:
                    root.blit(img.line, (293, 85))
                elif (a.position + a.direction) % 4 == 3:
                    root.blit(img.line, (870, 145))

    elif a.play_mode == pm.win and a.winner != -1:
        
        clock = pygame.time.Clock()
        running = True
        objects = [] 


        score = a.check_points()
        p = a.order_of_players()
        first = p[0]
        second = p[1]
        third = p[2]
        fourth = p[3]

        scoreboard = a.scoreboard()
        player1_score = str(0)
        player2_score = str(30)
        player3_score = str(40)
        player4_score = str(50)
        
        

     
        if music_on:
            sound.victory.play()

        string = ""
        if a.winner == 0:
            string = "Well Done! You've Won this Round!"
        else:
            print(f"bot map = {a.ai_name}, winner = {a.winner} ")
            string = "%s has won this Round" % a.ai_name[a.winner]

  
#        
        falling_animation()
        leaderboard()


    if music_on:
        root.blit(img.mute, (960, 8))
    else:
        root.blit(img.unmute, (960, 8))


    pygame.display.update()
