import itertools
import random


def peek(s):
    """Peek"""
    return s[-1]


def create_deck(uno):
    """Dealing the cards"""
    a = ('0', '1', '1', '2', '2', '3', '3', '4', '4', '5', '5', '6', '6', '7', '7', '8', '8', '9', '9',
         '+2', '+2', 'Skip', 'Skip', 'Reverse', 'Reverse')
    uno.deck1 = list(itertools.product(a, uno.color_list))  # Deck created
    for _ in range(4):  # Adds special black cards to decks
        uno.deck1.append(('Wild', 'Black'))
        uno.deck1.append(('+4', 'Black'))
    random.shuffle(uno.deck1)  # Shuffles deck

    while peek(uno.deck1) in [('Wild', 'Black'), ('+4', 'Black'), ('Skip', 'Red'), ('Skip', 'Green'),
                             ('Skip', 'Blue'), ('Skip', 'Yellow'), ('Reverse', 'Red'), ('Reverse', 'Green'),
                             ('Reverse', 'Blue'), ('Reverse', 'Yellow'), ('+2', 'Red'), ('+2', 'Green'),
                             ('+2', 'Blue'), ('+2', 'Yellow')]:  # First card cannot be special card
        random.shuffle(uno.deck1)

    uno.deck2.append(uno.deck1.pop())  # Shifts first card to played deck
    uno.current_card = peek(uno.deck2)  # Peek from played deck

    for j in range(4):  # Deals cards to player
        for _ in range(7):
            uno.players_cards_list[j].append(uno.deck1.pop())

    # uno.players_cards_list[0] = [('Wild', 'Black'), ('+4', 'Black'), ('Skip', 'Red'), ('Reverse', 'Green'), ("+2", "Blue")]


def next_position(uno, default):
    """Decides next player"""
    if uno.current_card[0] == 'Reverse' and uno.check_special == 0:
        uno.direction *= -1  # Direction reversed
        uno.check_special = 1  # Special card status inactive
    if uno.current_card[0] == 'Skip' and uno.check_special == 0:
        uno.check_special = 1
        uno.position = (uno.position + uno.direction) % 4

    if default:
        uno.position = (uno.position + uno.direction) % 4


def re_set(uno):
    """Reinitialize all the game variables and flags"""
    uno.background_voice = ""  # To print message
    uno.winner = -1
    uno.playing_check = False
    uno.extend_time = -1
    uno.players_cards_list = [[], [], [], []]
    uno.deck1 = list()
    uno.deck2 = list()
    uno.direction = 1  # Flag to check direction of play
    uno.position = -1  # Position counter
    uno.check_special = 0  # Flag to check status of special card
    uno.current_card = tuple()
    uno.drawn, uno.played, uno.color_chosen = False, False, False
    uno.win_check = [True] * 4
    uno.level1ai = True

    # Dealing the cards
    create_deck(uno)


def deal2and4(uno, n):
    """Handles +2 and +4 cards"""
    for _ in range(n):
        try:
            uno.players_cards_list[uno.position].append(uno.deck1.pop())
        except:
            uno.deck1, uno.deck2 = uno.deck2, uno.deck1
            random.shuffle(uno.deck1)
            uno.players_cards_list[uno.position].append(uno.deck1.pop())
    uno.background_voice = "%s Draws %d cards" % (uno.ai_name[uno.position], n)
    uno.check_special = 1


def deal_black_cards(uno, item):
    """Handles black cards"""
    uno.check_special = 0
    uno.deck2.append(item)
    uno.current_card = peek(uno.deck2)
    if not uno.level1ai:  # Color picker for hard mode
        d = dict()
        d['Blue'] = 0
        d['Green'] = 0
        d['Yellow'] = 0
        d['Red'] = 0
        d['Black'] = 0
        for _item in uno.players_cards_list[uno.position]:
            d[_item[1]] += 1
        d = sorted(d.items(), key=lambda kv: (kv[1], kv[0]))
        new_color = d[-1][0]  # Picks  most frequent color
        if new_color == 'Black':
            new_color = d[-2][0]
    else:
        new_color = random.choice(uno.color_list)  # Random color picked for easy mode
    uno.background_voice = "%s plays %s %s, new color is %s" % (uno.ai_name[uno.position], item[0], item[1], new_color)
    uno.current_card = (uno.current_card[0], new_color)
