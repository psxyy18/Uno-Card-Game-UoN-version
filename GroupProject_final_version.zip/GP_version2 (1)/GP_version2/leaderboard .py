import pygame
from deck import *
import random

# CONSTANTS

screen_width = 800
screen_height = 600
FPS = 60
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
running = True
objects = [] # to store objects for falling animation


a.check_points()
a.order_of_players()
first = a.order_of_players()[0]
second = a.order_of_players()[1]
third = a.order_of_players()[2]
fourth = a.order_of_players()[3]

scoreboard = a.scoreboard()
player1_score = str(scoreboard[first])
player2_score = str(scoreboard[second])
player3_score = str(scoreboard[third])
player4_score = str(scoreboard[fourth])

########################################################################################################################
# CLASSES

# This class is for the objects in the falling animation
class Falling:
    def __init__(self, x, y, speed):
        self.x = x
        self.y = y
        self.speed = speed


    def move(self):

        self.y += self.speed

        # if object reaches bottom of screen
        if self.y > screen_height:
            # reset to top of display
            self.y = 0
            self.x = random.randint(0, screen_width)


class Button:
    def __init__(self, x, y, text, font, text_colour, text_size, width, height, button_colour):
        pygame.font.init()
        self.x = x
        self.y = y
        self.text = text
        self.font = font
        self.text_colour = text_colour
        self.text_size = text_size
        self.width = width
        self.height = height
        self.button_colour = button_colour
        self.button_colour_copy = button_colour  # for the button interaction

        # colours must be given in (_,_,_) form.

    def ellipse_button(self):
        pygame.draw.ellipse(screen, self.button_colour, (self.x, self.y, self.width, self.height))
        text_font = pygame.font.SysFont(self.font, self.text_size)
        text_width, text_height = text_font.size(self.text)
        text = text_font.render(self.text, True, self.text_colour)
        screen.blit(text, (self.x + self.width / 2 - text_width / 2, self.y + self.height / 2 - text_height / 2))


    def button_highlight(self):  # highlights a button when mouse hovers over it
        mouse_x, mouse_y = pygame.mouse.get_pos()
        yellow = (255, 255, 0)
        if self.x + self.width >= mouse_x >= self.x and self.y + self.height >= mouse_y >= self.y:
            self.button_colour = yellow
        else:
            self.button_colour = self.button_colour_copy


class Text:
    def __init__(self, text, font, size, colour):
        pygame.font.init()
        self.text = text
        self.font = font
        self.size = size
        self.colour = colour


    def insert_text(self, x, y):
        text_font = pygame.font.SysFont(self.font, self.size)
        text_tbd = text_font.render(self.text, True, self.colour)
        screen.blit(text_tbd, (x, y))

    def get_text_dim(self):
        text_font = pygame.font.SysFont(self.font, self.size)
        text_width, text_height = text_font.size(self.text)
        dimensions = text_width, text_height
        return dimensions


########################################################################################################################
# FUNCTIONS

def create_falling_objects():
    for i in range(40):
        x = random.randint(0, screen_width)
        y = random.randint(0, screen_height)
        speed = random.randint(7, 15)

        object = Falling(x, y, speed)
        objects.append(object)


def falling_animation():
    for object in objects:
        object.move()

    # Draw objects
    screen.fill((0, 0, 0))  # Clear the screen
    for object in objects:
        im = pygame.image.load('Uno_logo_PNG2.png')
        image = pygame.transform.scale(im, (20, 26))
        screen.blit(image, (object.x, object.y))


def leaderboard():


    play_again = Button(20, 450, 'Play again', None, (0, 0, 0), 40, 200, 100, (255, 0, 0))
    play_again.button_highlight()
    play_again.ellipse_button()

    quit_button = Button(580, 450, 'Quit', None, (0, 0, 0), 40, 200, 100, (255, 0, 0))
    quit_button.button_highlight()
    quit_button.ellipse_button()

    GO_message = Text('Game Over!', None, 100, (255, 255, 255))
    GO_message.insert_text(200, 100)

    first_txt = Text('1st Place: ' + first + '(' + player1_score + ')', None, 35, (255, 255, 255))
    second_txt = Text('2nd Place: ' + second + '(' + player2_score + ')', None, 35, (255, 255, 255))
    third_txt = Text('3rd Place: ' + third + '(' + player3_score + ')', None, 35, (255, 255, 255))
    fourth_txt = Text('4th Place: ' + fourth + '(' + player4_score + ')', None, 35, (255, 255, 255))

    GO_mid = GO_message.get_text_dim()[0]/2 + 200
    x_first = GO_mid - first_txt.get_text_dim()[0]/2
    x_second = GO_mid - second_txt.get_text_dim()[0]/2
    x_third = GO_mid - third_txt.get_text_dim()[0]/2
    x_fourth = GO_mid - fourth_txt.get_text_dim()[0]/2

    first_txt.insert_text(x_first, 200)
    second_txt.insert_text(x_second, 300)
    third_txt.insert_text(x_third, 400)
    fourth_txt.insert_text(x_fourth, 500)



########################################################################################################################

# GAME LOOP

create_falling_objects()
game_end = True       

# Main game loop
while running:

    if game_end:

        falling_animation()
        leaderboard()
        # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            if game_end:
                if event.button == 1:

                    mouse_pos = pygame.mouse.get_pos()


                    if (580 <= mouse_pos[0] <= 580 + 200 and   # quit button
                        450 <= mouse_pos[1] <= 450 + 100):
                        running = False

                    if (20 <= mouse_pos[0] <= 20 + 200 and
                        450 <= mouse_pos[1] <= 450 + 100):      #Play again button
                        ess.play_mode = pm.load



    pygame.display.flip()

    clock.tick(FPS)


