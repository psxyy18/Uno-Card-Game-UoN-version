import random
from deck import *



def choose_a_color(m, ess, music_on, sound):
    if 395 < m[0] < 440 and 390 < m[1] < 450:  # Red Button
        ess.color_chosen = False
        a.card_select_color("Red")
        if music_on:
            sound.click.play()
    if 450 < m[0] < 495 and 390 < m[1] < 450:  # Green Button
        ess.color_chosen = False
        a.card_select_color( "Green")
        if music_on:
            sound.click.play()
    if 505 < m[0] < 550 and 390 < m[1] < 450:  # Blue Button
        ess.color_chosen = False
        a.card_select_color("Blue")
        if music_on:
            sound.click.play()
    if 560 < m[0] < 605 and 390 < m[1] < 450:  # Yellow Button
        ess.color_chosen = False
        a.card_select_color("Yellow")
        if music_on:
            sound.click.play()


